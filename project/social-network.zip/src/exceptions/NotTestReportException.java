package exceptions;

/**
* <i>NotTestReportException</i> is raised when some TestReport can not be created with the given arguments
* 
*/
public class NotTestReportException extends Exception {

}
