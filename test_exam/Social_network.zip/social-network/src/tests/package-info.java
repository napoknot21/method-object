/**
 * Tests for the SocialNetwork
 */

package tests;
SocialNetwork Facebook= new SocialNetwork(["A"])