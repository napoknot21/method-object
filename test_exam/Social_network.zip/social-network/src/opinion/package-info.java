/**
 * Main package for SocialNetwork 
 */
package opinion;