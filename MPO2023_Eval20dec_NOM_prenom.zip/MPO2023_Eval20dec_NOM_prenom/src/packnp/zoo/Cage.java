package packnp.zoo;

import java.util.LinkedList;

public class Cage{

}
