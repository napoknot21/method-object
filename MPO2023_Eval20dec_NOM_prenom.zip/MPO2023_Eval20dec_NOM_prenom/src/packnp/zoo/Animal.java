package packnp.zoo;

public class Animal{

	public Animal(String nom, String espece) {
		
	}
}
