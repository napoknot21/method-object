package packnp.pharmacie;


public class Medicament {
	// A vous de completer

}
